package aula.thread;

public class TesteThread {

	public static void main(String[] args) {
		Job1 j1 = new Job1();
		Thread t1 = new Thread(j1);
		t1.start();
		
		Job2 j2 = new Job2();
		Thread t2 = new Thread(j2);
		t2.start();
		
		for (int i = 0; i < 1000000; i++) { 
			System.out.printf("Principal\n");
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}		
	}

}
